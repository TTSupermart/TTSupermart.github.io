# T&T Supermart Website

Static website for T&T Supermart, designed for GitHub Pages.

## Files

- `index.html` - main website page
- `styles.css` - website styling
- `script.js` - small script for current year in footer
- `assets/tt-supermart-logo.png` - recreated store logo

## Recommended GitHub Pages setup

1. Sign in to GitHub as `TTSupermart`.
2. Create a new public repository named `TTSupermart.github.io`.
3. Upload all files from this folder directly into the repository.
4. Commit the files.
5. Go to **Settings > Pages**.
6. Under **Build and deployment**, choose:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`
7. Save.
8. Your site should publish at `https://TTSupermart.github.io/` after GitHub finishes deploying.

## Editing later

Update `index.html` text for weekly specials, departments, services, and any future social links. Replace `assets/tt-supermart-logo.png` if you choose a revised logo later.
